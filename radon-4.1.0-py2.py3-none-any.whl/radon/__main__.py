"""Module allowing for ``python -m radon ...``."""
from radon import main

main()
