if __name__ == '__main__':
    import pytest
    ret = pytest.main(['--strict'])
    exit(ret)
