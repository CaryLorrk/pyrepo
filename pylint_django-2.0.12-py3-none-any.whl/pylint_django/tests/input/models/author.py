# pylint: disable=missing-docstring,wrong-import-position
from django.db import models


class Author(models.Model):
    pass
