"""
Checks that Pylint does not complain about import of Q.
"""
#  pylint: disable=missing-docstring,unused-import
from django.db.models import Q  # noqa: F401
