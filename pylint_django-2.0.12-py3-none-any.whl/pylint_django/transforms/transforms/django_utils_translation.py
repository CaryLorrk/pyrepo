def ugettext_lazy(_):
    return ''
