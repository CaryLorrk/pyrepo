
from jupyterlab_server.app import main
import sys

sys.exit(main())
