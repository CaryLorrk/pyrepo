pytest_plugins = [
    "jupyter_server.pytest_plugin",
    "jupyterlab_server.pytest_plugin"
]