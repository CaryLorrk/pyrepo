from whitelist_utils import Whitelist

# To free memory, the "default_factory" attribute can be set to None.
whitelist_defaultdict = Whitelist()
whitelist_defaultdict.default_factory
