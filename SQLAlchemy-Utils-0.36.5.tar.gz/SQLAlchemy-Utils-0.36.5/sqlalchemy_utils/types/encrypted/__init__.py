# Module for encrypted type
