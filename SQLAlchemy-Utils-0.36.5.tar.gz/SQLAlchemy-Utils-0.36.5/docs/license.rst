License
=======

.. include:: ../LICENSE
