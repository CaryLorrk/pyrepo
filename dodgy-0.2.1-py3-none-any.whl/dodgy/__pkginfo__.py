VERSION = (0, 2, 1)


def get_version():
    return ".".join([str(v) for v in VERSION])
