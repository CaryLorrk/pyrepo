import dodgy.run

dodgy.run.main()
